It is a really small flask app


